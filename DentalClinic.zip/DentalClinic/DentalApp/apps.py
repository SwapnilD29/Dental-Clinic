from django.apps import AppConfig


class DentalappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DentalApp'
